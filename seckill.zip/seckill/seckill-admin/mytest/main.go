package mytest

func main() {
	RunService()
}
